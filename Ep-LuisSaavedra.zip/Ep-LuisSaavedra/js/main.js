function loadJs() {


    var formulario = document.createElement("form");
    formulario.id = 'formulario'

    //Elementos del formulario
    var componentes = [
        { "id": "txt1", "label": 'Tasa Efectiva Anual:', "type": "number" },
        { "id": "txt2", "label": "Plazo en meses", "type": "number" },
        { "id": "txt3", "label": "Monto Total del Vehichilo:", "type": "number" },
        { "id": "txt4", "label": "Monto Inicial:", "type": "number" },
        { "id": "btnCalcular", "label": "Calcular", "type": "button" },
        { "id": "btnReset", "label": "Reset", "type": "button" },
        { "id": "txt5", "label": "Total Interes:", "type": "number" },
        { "id": "txt6", "label": "Pago mensual:", "type": "number" },
        { "id": "txt7", "label": "Total a Pagar:", "type": "number" }
    ]

    //creacion del formulario
    componentes.forEach((input) => {
        var label = document.createElement("label");
        var inputs = document.createElement("input");
        var contenedor = document.createElement("div");

        label.innerHTML = input.label;//ponerle el texto del objeto en el laber
        inputs.type = input.type;//el imput creado que tipo sera
        inputs.id = input.id;//el imput tendra como id el id del objeto


        if (input.type == "button") {
            inputs.value = input.label;
            contenedor.appendChild(inputs);

        } else {
            contenedor.appendChild(label);
            contenedor.appendChild(inputs);
        }


        formulario.appendChild(contenedor);
    })



    var tabla = document.createElement('table');
    var fila = document.createElement('tbody');
    var casilla = document.createElement('td');

    tabla.id = 'tabla';
    fila.id = 'fila';
    casilla.id = 'casilla';

    var encabezados = ['Parc', 'Amort', 'Interes', 'Desgravamen', 'Cuota', 'Pago', 'Saldo']

    encabezados.forEach(title => {
        var Tcasilla = document.createElement('td');
        Tcasilla.id = 't-c';
        Tcasilla.innerHTML = title;
        fila.appendChild(Tcasilla);

    });

    tabla.appendChild(fila);



    function refrescar() {
        location.reload(true);
    }

    var divroot = document.getElementById('root');
    divroot.appendChild(formulario);
    divroot.appendChild(tabla);



    var btnCalcular = document.getElementById('btnCalcular');

    var btnReset = document.getElementById('btnReset');
    btnReset.onclick = refrescar;

    btnCalcular.addEventListener("click", event => {

        var Teatxt = document.getElementById('txt1');
        var Mesestxt = document.getElementById('txt2');
        var Totaltxt = document.getElementById('txt3');
        var Initxt = document.getElementById('txt4');
        console.log(Teatxt.value, Mesestxt.value, Totaltxt.value, Initxt.value);


        //formulas matematicas
        var TEA = Teatxt.value * 1 / 100;
        var TEM = ((1 + TEA ** 1 / 12) - 1);

        var inicial = (Initxt.value * 1 / 100) * Totaltxt.value;
        var capital = Totaltxt.value - inicial;
        var cuotaMensual = capital * (((1 + TEM) ** Mesestxt.value) * TEM) / (((1 + TEM) ** Mesestxt.value) - 1);
        var interes = capital * TEM;
        var amortiza = cuotaMensual - interes;
        var saldo = capital - amortiza;
        var desgravamen = capital * 0.005;
        var pagoMensual = cuotaMensual + desgravamen;
        var totalPrestamo = pagoMensual * Mesestxt.value;
        var totalInteres = totalPrestamo - capital;


        //calculos de las funciones


        //generar tablas
        function Genera_tabla() {
            var mes = document.getElementById('txt2');
            for (var i = 0; i <= mes.value; i++) {

                var Ofila = document.createElement('tbody');
                Ofila.id = 'Ofila';


                encabezados.forEach(title => {
                    var Ocasilla = document.createElement('tr');
                    Ocasilla.id = 'Ocasilla';
                    var DatoAmort = amortiza.toFixed(2); var DatoInteres = interes.toFixed(2); var DatoCapital = capital.toFixed(2); var Datocuota = cuotaMensual.toFixed(2);
                    switch (title) {

                        case 'Parc':
                            Ocasilla.innerHTML = i;

                            break;

                        case 'Interes':
                            if (i < 1) {
                                Ocasilla.innerHTML = "";

                            } else {

                                var intee = (DatoCapital * 0.05);
                                DatoInteres = intee;
                                Ocasilla.innerHTML = DatoInteres.toFixed(2);



                            }
                            break;
                        case 'Amort':
                            if (i < 1) {

                                Ocasilla.innerHTML = "";

                            } else {

                                var Amo = Datocuota - DatoInteres;
                                DatoAmort = Amo;
                                Ocasilla.innerHTML = DatoAmort.toFixed(2);

                            }
                            break;
                        case 'Desgravamen':
                            if (i < 1) {
                                Ocasilla.innerHTML = "";
                            } else {
                                Ocasilla.innerHTML = desgravamen.toFixed(2);
                            }

                            break;
                        case 'Cuota':
                            if (i < 1) {
                                Ocasilla.innerHTML = "";

                            } else {
                                Ocasilla.innerHTML = cuotaMensual.toFixed(2);
                            }


                            break;
                        case 'Pago':
                            if (i < 1) {
                                Ocasilla.innerHTML = "";
                            } else {
                                Ocasilla.innerHTML = pagoMensual.toFixed(2);
                            }


                            break;
                        case 'Saldo':
                            if (i < 1) {
                                Ocasilla.innerHTML = capital.toFixed(2);
                            }
                            else {
                                DatoCapitalv2 = DatoCapital - DatoAmort;
                                DatoCapital = DatoCapitalv2;
                                Ocasilla.innerHTML = DatoCapitalv2.toFixed(2);
                            }


                    }

                    txt5.value = totalInteres.toFixed(2);
                    txt6.value = pagoMensual.toFixed(2);
                    txt7.value = totalPrestamo.toFixed(2);

                    console.log("Dato capital ", DatoCapital, "Dato Amort ", DatoAmort, "Dato Interes", DatoInteres);
                    Ofila.appendChild(Ocasilla);
                    tabla.appendChild(Ofila);
                });
            } console.log("tabla creada")




        }//funcion
        btnCalcular.onclick = Genera_tabla;






        console.log('la TEA es :' + TEA);
        console.log('el TEM es :' + TEM);
        console.log('eL Capital es :' + capital);
        console.log('eL Inicial es :' + inicial);
        console.log('la cuota mensual es :' + cuotaMensual);
        console.log('valor amortizado: ' + amortiza);
        console.log('valor interes: ' + interes);
        console.log('valor desgravamen: ' + desgravamen);
        console.log('valor pagototalmes: ' + pagoMensual);
        console.log('saldo: ' + saldo);
        console.log('el total de interes es :' + totalInteres)
        console.log('el total del prestamo es :' + totalPrestamo);

    })
}


document.addEventListener('DOMContentLoaded', loadJs)